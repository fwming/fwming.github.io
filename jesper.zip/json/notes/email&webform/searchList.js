{
	"msg": "1",
	"data": [{
		"url": "notes/email/key",
		"title": "EDM"
	},{
		"url": "notes/email/template",
		"title": "EDM/模板"
	},{
		"url": "notes/email/mailbox",
		"title": "EDM/测试"
	},{
		"url": "notes/webform/",
		"title": "webform"
	},{
		"url": "notes/webform/data",
		"title": "webform/data"
	},{
		"url": "notes/webform/datepicker",
		"title": "webform/datepicker"
	},{
		"url": "notes/webform/datepicker-title",
		"title": "webform/datepicker提示"
	},{
		"url": "notes/webform/phone",
		"title": "webform/phone"
	},{
		"url": "notes/webform/fancybox",
		"title": "webform/fancybox弹窗"
	}]
}
