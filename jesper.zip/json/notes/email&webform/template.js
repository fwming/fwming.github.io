{
	"code": 0,
	"msg": "",
	"data": [{
		"title": "基础模板",
		"data": [{
			"disabled": false,
			"value": "v1.5",
			"status": "pass",
			"txt": "V 1.5"
		},{
			"disabled": false,
			"value": "v1.6",
			"status": "pass",
			"txt": "V 1.6"
		}]
	},{
		"title": "TEST",
		"data": [{
			"disabled": true,
			"value": "test-error",
			"status": "error",
			"txt": "test-error 演示项 无法加载 :2020-08-06"
		},{
			"disabled": true,
			"value": "test-warning",
			"status": "warning",
			"txt": "test-warning 演示项 无法加载 :2020-08-06"
		}]
	},{
		"title": "CASIO",
		"data": [{
			"disabled": false,
			"value": "casio",
			"status": "pass",
			"txt": "casio :2020-08-06"
		}]
	},{
		"title": "RMK",
		"data": [{
			"disabled": false,
			"value": "rmk",
			"status": "pass",
			"txt": "rmk :2020-08-06"
		}]
	},{
		"title": "REEBOK",
		"data": [{
			"disabled": false,
			"value": "reebok",
			"status": "pass",
			"txt": "reebok :2020-08-06"
		}]
	},{
		"title": "KANEBO",
		"data": [{
			"disabled": false,
			"value": "kanebo",
			"status": "pass",
			"txt": "kanebo :2020-08-06"
		}]
	},{
		"title": "CHANEL",
		"data": [{
			"disabled": false,
			"value": "chanel-en",
			"status": "pass",
			"txt": "chanel-en :2020-08-06"
		},{
			"disabled": false,
			"value": "chanel-cn",
			"status": "pass",
			"txt": "chanel-cn :2020-08-06"
		}]
	},{
		"title": "MARCOPOLOHOTELS",
		"data": [{
			"disabled": false,
			"value": "rewards-special-en",
			"status": "pass",
			"txt": "Rewards Special-en :2020-08-06"
		},{
			"disabled": false,
			"value": "rewards-special-cn",
			"status": "pass",
			"txt": "Rewards Special-cn :2020-08-06"
		},{
			"disabled": false,
			"value": "getaway-en",
			"status": "pass",
			"txt": "Getaway-en :2020-08-06"
		},{
			"disabled": false,
			"value": "getaway-cn",
			"status": "pass",
			"txt": "Getaway-cn :2020-08-06"
		},{
			"disabled": false,
			"value": "marco-polo-getaway-en",
			"status": "pass",
			"txt": "Marco Polo Getaway-en :2020-08-06"
		},{
			"disabled": false,
			"value": "marco-polo-getaway-cn",
			"status": "pass",
			"txt": "Marco Polo Getaway-cn :2020-08-06"
		}]
	}]
}
